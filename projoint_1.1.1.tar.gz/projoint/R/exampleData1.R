#' Projoint Example Data Set 1: Building Conjoint with a Repeated, Flipped Task
#'
#' A cleaned Qualtrics export from a conjoint study that compares two potential
#' new building developments. Each respondent completed 8 standard tasks as well
#' as a repeated version of the first task (flipped), which can be used to
#' calculate intra-respondent reliability (response instability).
#'
#' @docType data
#' @usage data(exampleData1)
#'
#' @format A data frame with 400 rows and 185 columns. Contains survey responses
#'   including demographic information, outcome choices, and conjoint attribute
#'   values identified by \code{K-*-*} variable names.
#'
#' @keywords datasets
#'
#' @examples
#' # Load the dataset
#' data(exampleData1)
#'
#' # Inspect the first few rows
#' head(exampleData1)
#'
#' # Number of rows and columns
#' dim(exampleData1)
#'
#' # Display column names (truncated here)
#' names(exampleData1)[1:10]
#'
#' @name exampleData1
NULL
