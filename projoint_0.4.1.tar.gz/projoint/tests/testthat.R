#library(tidyverse)
library(testthat)
library(projoint)

test_check("projoint")
